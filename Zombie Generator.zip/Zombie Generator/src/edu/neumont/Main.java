package edu.neumont;

import edu.neumont.controllers.Controller;
import edu.neumont.utils.ZedGenerator;

public class Main {

    public static void main(String[] args) {
	// write your code here
        Controller controller = new Controller();
        controller.run();
    }
}
